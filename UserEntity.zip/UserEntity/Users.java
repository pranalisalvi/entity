package com.capgemini.appl.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="Users")
@Table(name="Users")
public class Users {

	String login_id;
	String password;
	String role;

	public Users() {
		super();
	}

	public Users(String login_id, String password, String role) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.role = role;
	}

	@Id
	@Column(name="login_id")
	@Size(min=1, max=4, message="Id must be of size 1 to 4.")
	public String getLogin_id() {
		return login_id;
	}

	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}

	@NotEmpty(message="Password is required.")
	@Size(min=1, max=8, message="Password must be of size 1 to 8.")
	@Column(name="password")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name="role")
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "Users [login_id=" + login_id + ", password=" + password
				+ ", role=" + role + "]";
	}

}
